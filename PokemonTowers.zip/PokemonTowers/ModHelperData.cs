namespace MyMod;

public static class ModHelperData
{
    public const string Version = "0.1.0";
    public const string Name = "Pokemon Towers";

    public const string Description = "An empty mod";

    public const string RepoOwner = ""; // TODO add your github username hero, also in the download url in README.md
    public const string RepoName = ""; // TODO add your repo name here, also in the download url in README.md
}