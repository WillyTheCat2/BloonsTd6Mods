using BTD_Mod_Helper;
using MelonLoader;

[assembly: MelonInfo(typeof(TemplateMod.Main), "Pokemon Towers", "0.1.0", "WillyTheCat")]
[assembly: MelonGame("Ninja Kiwi", "BloonsTD6")]
namespace TemplateMod
{
    public class Main : BloonsTD6Mod
    {

    }
}